%% Demo of A Latin Square Image Cipher
% -------------------------------------------------------------------------
% For more information, please refer to our paper
% "A Novel Latin Square Image Cipher" via http://arxiv.org/abs/1204.2310
% -------------------------------------------------------------------------
% By Dr. Yue Wu
% Email: ywu03@ece.tufts.edu
% ECE Dept, Tufts University
% 04/10/2012
% -------------------------------------------------------------------------
% The provided code is free to be used, modified and distributed for
% research purposes only. 
% If you use the code in your paper, please cite our paper. 
% -------------------------------------------------------------------------

%% 0. Clean up
clear all
close all
clc

%% 1. Encryption and Decryption Speed
P = imread('cameraman.tif'); %<--------- replace any of your interested 256x256 images here
K = RandomKey;
tic
C = LatinSqEnc2(double(P),K);
t(1,1) = toc
tic
D = LatinSqDec2(C,K);
t(1,2) = toc

figure(1),subplot(2,3,1),imshow(P,[]),title('Plaintext Image P')
subplot(2,3,2),imshow(C,[]),title('Ciphertext Image C = Enc(P,K)')
subplot(2,3,3),imshow(D,[]),title('Deciphertext Image D = Dec(C,K)' )
subplot(2,3,4),imhist(uint8(P)),title('Histogram of P')
subplot(2,3,5),imhist(uint8(C)),title('Histogram of C')
subplot(2,3,6),imhist(uint8(D)),title('Histogram of D')


%% 2. Probabilistic Encryption
tic
C2 = LatinSqEnc2(double(P),K);
t(2,1) = toc

tic
D2 = LatinSqDec2(C2,K);
t(2,2) = toc

figure(2),subplot(2,4,1),imshow(C,[]),title('Ciphertext Image C_1')
subplot(2,4,2),imshow(C2,[]),title('Ciphertext Image C_2')
subplot(2,4,3),imshow(imabsdiff(C,C2),[]),title('|C_1-C_2|')
subplot(2,4,4),imhist(uint8(imabsdiff(C,C2))),title('Histogram of |C_1-C_2|'),axis square
subplot(2,4,5),imshow(D,[]),title('Deciphertext Image D_1')
subplot(2,4,6),imshow(D2,[]),title('Deciphertext Image D_2')
subplot(2,4,7),imshow(imabsdiff(D,D2),[]),title('|D_1-D_2|')
subplot(2,4,8),imhist(uint8(imabsdiff(D,D2))),title('Histogram of |D_1-D_2|'),axis square

%% 3. Robustness to Noise in Ciphertext
r = round(rand(1)*65536);
Cn = C;
Cn(r) = 0;
Dn = LatinSqDec2(Cn,K);

Cn2 = C;
Cn2(125:135,125:135) = 0;
Dn2 = LatinSqDec2(Cn2,K);

figure(3),subplot(2,3,1),imshow(P,[]),title('Plaintext Image P')
subplot(2,3,2),imshow(Cn,[]),title('Noisy Ciphertext Image C_n')
subplot(2,3,3),imshow(Dn,[]),title('Deciphertext Image D_n')
subplot(2,3,4),imshow(C,[]),title('Ciphertext Image C')
subplot(2,3,5),imshow(Cn2,[]),title('Noisy Ciphertext Image C_n_2')
subplot(2,3,6),imshow(Dn2,[]),title('Deciphertext Image D_n_2')

%% 4. Sensitivity to Key Changes
K2 = K;
b = randi(64);
K2(b)= dec2hex(bitxor(uint8(hex2dec(K(b))),1)); % randomly change 1bit in K

CK = LatinSqEnc2(P,K2);
DK = LatinSqDec2(CK,K2);

figure(4)
subplot(2,3,1),imshow(C,[]),title('Ciphertext Image C = Enc(P,K)')
subplot(2,3,2),imshow(C,[]),title('Ciphertext Image C_K_2 = Enc(P,K_2)')
subplot(2,3,3),imshow(imabsdiff(C,CK),[]),title('|C-C_K_2|')
subplot(2,3,4),imshow(D,[]),title('Deciphertext Image D = Dec(C,K)' )
subplot(2,3,5),imshow(DK,[]),title('Deciphertext Image D_K_2 = Dec(C_K_2,K_2)')
subplot(2,3,6),imshow(imabsdiff(D,DK),[]),title('|D-D_K_2|')

%% 5. Sensitivity to Plaintext Changes
P2 = P;
P2(r) = 0;
C2 = LatinSqEnc2(P2,K);
D2 = LatinSqDec2(C2,K);

figure(5)
subplot(3,3,1),imshow(P,[]),title('Plaintext Image P')
subplot(3,3,2),imshow(C,[]),title('Ciphertext Image C = Enc(P,K)')
subplot(3,3,3),imshow(D,[]),title('Deciphertext Image D = Dec(C,K)' )
subplot(3,3,4),imshow(P2,[]),title('Plaintext Image P_2')
subplot(3,3,5),imshow(C2,[]),title('Ciphertext Image C_2 = Enc(P_2,K)')
subplot(3,3,6),imshow(D2,[]),title('Deciphertext Image D_2 = Dec(C_2,K)' )
subplot(3,3,7),imshow(uint8(imabsdiff(P,P2))),title('|P-P_2|')
subplot(3,3,8),imshow(imabsdiff(C,C2),[]),title('|C-C_2|')
subplot(3,3,9),imshow(imabsdiff(D,DK),[]),title('|D-D_K_2|')
